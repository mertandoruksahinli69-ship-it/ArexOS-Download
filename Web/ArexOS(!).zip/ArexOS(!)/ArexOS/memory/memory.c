#include <stdint.h>

#define MEM_START 0x100000
#define MEM_SIZE  0x100000

static uint32_t mem_offset = 0;

void* arex_alloc(uint32_t size) {
    void* ptr = (void*)(MEM_START + mem_offset);
    mem_offset += size;
    return ptr;
}
