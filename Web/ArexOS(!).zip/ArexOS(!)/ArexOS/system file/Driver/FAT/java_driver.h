#ifndef JAVA_DRIVER_H
#define JAVA_DRIVER_H
#include "driver.h"

extern Driver JAVA_DRIVER;

#endif
