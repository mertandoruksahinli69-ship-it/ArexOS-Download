#ifndef EXE_DRIVER_H
#define EXE_DRIVER_H
#include "driver.h"

extern Driver EXE_DRIVER;

#endif
