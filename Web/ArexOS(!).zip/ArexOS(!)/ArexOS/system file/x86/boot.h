#ifndef AREX_X86_BOOT_H
#define AREX_X86_BOOT_H

/* Architecture */
#define AREX_ARCH_X86 1

/* Boot modes */
#define AREX_BOOT_REALMODE 1
#define AREX_BOOT_PROTECTEDMODE 2

/* Memory layout */
#define AREX_BOOT_ADDR   0x7C00
#define AREX_STAGE2_ADDR 0x8000
#define AREX_KERNEL_ADDR 0x00100000

/* Entry points */
void arex_stage2_entry(void);
void arex_kernel_entry(void);

#endif
