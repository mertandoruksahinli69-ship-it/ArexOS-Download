#include "vga.h"

extern void cpu_halt(void);

void kernel_main(void) {
    vga_clear();
    vga_print("AREX Kernel v0.1\n");
    vga_print("Boot successful.\n");

    while (1) {
        cpu_halt();
    }
}