#ifndef VGA_H
#define VGA_H

#include "types.h"

void vga_clear(void);
void vga_print(const char* str);

#endif
