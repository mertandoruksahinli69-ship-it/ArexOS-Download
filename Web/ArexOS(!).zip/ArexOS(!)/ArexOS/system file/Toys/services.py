import threading
import time

def disk_service():
    while True:
        print("[Disk Service] Checking disk health...")
        time.sleep(5)  # 5 saniyede bir kontrol

def update_service():
    while True:
        print("[Update Service] Checking for updates...")
        time.sleep(10)  # 10 saniyede bir kontrol

def main():
    # Threadler olarak servisleri başlat
    disk_thread = threading.Thread(target=disk_service, daemon=True)
    update_thread = threading.Thread(target=update_service, daemon=True)

    disk_thread.start()
    update_thread.start()

    print("Helper services started! Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)  # Ana thread beklemede
    except KeyboardInterrupt:
        print("Exiting services...")

if __name__ == "__main__":
    main()
