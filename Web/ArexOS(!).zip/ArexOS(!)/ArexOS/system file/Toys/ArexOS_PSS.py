import tkinter as tk
from tkinter import ttk
import psutil
import threading
import time

# --- Pencere ---
root = tk.Tk()
root.title("ArexOS Görev Yöneticisi")
root.geometry("800x600")
root.configure(bg="black")

# --- Başlık ---
title = tk.Label(root, text="ArexOS Görev Yöneticisi", font=("Arial", 24, "bold"), fg="cyan", bg="black")
title.pack(pady=10)

# --- Treeview (Görev listesi) ---
columns = ("PID", "İsim", "CPU %", "RAM %")
tree = ttk.Treeview(root, columns=columns, show="headings")
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, anchor="center")
tree.pack(expand=True, fill="both", padx=20, pady=20)

# --- Stil ---
style = ttk.Style()
style.theme_use("default")
style.configure("Treeview", background="black", foreground="white", rowheight=25, fieldbackground="black")
style.map("Treeview", background=[('selected', 'cyan')], foreground=[('selected', 'black')])

# --- Görevleri güncelleyen fonksiyon ---
def update_tasks():
    while True:
        for i in tree.get_children():
            tree.delete(i)
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
            pid = proc.info['pid']
            name = proc.info['name']
            cpu = proc.info['cpu_percent']
            ram = proc.info['memory_percent']
            tree.insert("", "end", values=(pid, name, cpu, f"{ram:.2f}"))
        time.sleep(2)

# --- Thread ile arka planda çalıştır ---
thread = threading.Thread(target=update_tasks, daemon=True)
thread.start()

root.mainloop()
