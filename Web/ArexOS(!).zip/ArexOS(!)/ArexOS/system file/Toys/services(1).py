import threading
import time
import random

# --- Servisler ---
def disk_service():
    while True:
        print("[Disk Service] Disk sağlığı kontrol ediliyor...")
        time.sleep(5)

def update_service():
    while True:
        print("[Update Service] Güncellemeler kontrol ediliyor...")
        time.sleep(10)

def system_info_service():
    while True:
        cpu = random.randint(1, 100)
        ram = random.randint(1, 100)
        print(f"[System Info] CPU: {cpu}%, RAM: {ram}%")
        time.sleep(7)

def log_service():
    while True:
        print("[Log Service] Sistem logları kaydediliyor...")
        time.sleep(8)

def network_service():
    while True:
        print("[Network Service] Ağ bağlantısı sağlanıyor...")
        time.sleep(6)

def backup_service():
    while True:
        print("[Backup Service] Otomatik yedekleme kontrol ediliyor...")
        time.sleep(15)

# --- Servisleri başlat ---
def start_services():
    services = [
        disk_service,
        update_service,
        system_info_service,
        log_service,
        network_service,
        backup_service
    ]
    
    threads = []
    for service in services:
        t = threading.Thread(target=service, daemon=True)
        t.start()
        threads.append(t)
    
    print("Tüm yardımcı servisler çalışıyor! Ctrl+C ile çıkabilirsiniz.")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Servisler kapatılıyor...")

if __name__ == "__main__":
    start_services()
