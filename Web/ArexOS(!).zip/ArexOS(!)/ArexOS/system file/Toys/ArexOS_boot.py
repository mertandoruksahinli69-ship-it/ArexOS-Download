import tkinter as tk
import time
import random

# --- Pencere ---
root = tk.Tk()
root.title("ArexOS Boot")
root.attributes('-fullscreen', True)
root.configure(bg="black")

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# --- Arka plan yıldız efekti ---
stars = []
for _ in range(150):
    x = random.randint(0, screen_width)
    y = random.randint(0, screen_height)
    size = random.randint(1, 3)
    star = tk.Label(root, text="*", fg="white", bg="black", font=("Arial", size))
    star.place(x=x, y=y)
    stars.append(star)

# --- Logo ---
logo = tk.Label(root, text="AREXOS", font=("Arial", 96, "bold"), fg="cyan", bg="black")
logo.place(relx=0.5, rely=0.3, anchor='center')

# --- Yükleme çubuğu ---
bar_width = 600
bar_height = 40
canvas = tk.Canvas(root, width=bar_width, height=bar_height, bg="black", highlightthickness=0)
canvas.place(relx=0.5, rely=0.6, anchor='center')
bar = canvas.create_rectangle(0, 0, 0, bar_height, fill="green")

# --- Boot mesajları ---
msg_label = tk.Label(root, text="", font=("Arial", 24), fg="white", bg="black")
msg_label.place(relx=0.5, rely=0.75, anchor='center')

root.update()

# --- Animasyon parametreleri ---
progress = 0
messages = ["Initializing system...", "Loading drivers...", "Starting services...", "Boot complete!"]
msg_index = 0
colors = ["cyan", "light blue", "white", "blue", "magenta"]

def gradient_color(pos, max_pos):
    # Renk geçişi hesapla (yeşilden maviye)
    r = int(0 + (0-0)*(pos/max_pos))
    g = int(255 - (255-0)*(pos/max_pos))
    b = int(0 + (0+255)*(pos/max_pos))
    return f'#{r:02x}{g:02x}{b:02x}'

# --- Animasyon döngüsü ---
while progress <= bar_width:
    # Yıldızları hareket ettir
    for star in stars:
        y = star.winfo_y() + 1
        if y > screen_height:
            y = 0
        star.place(y=y)
    
    # Logo renk animasyonu
    logo.config(fg=random.choice(colors))
    
    # Yükleme çubuğu gradient
    color = gradient_color(progress, bar_width)
    canvas.itemconfig(bar, fill=color)
    canvas.coords(bar, 0, 0, progress, bar_height)
    
    # Mesaj değişimi
    if progress % 150 == 0 and msg_index < len(messages):
        msg_label.config(text=messages[msg_index])
        msg_index += 1
    
    root.update()
    progress += 6
    time.sleep(0.03)

time.sleep(1)
root.destroy()
