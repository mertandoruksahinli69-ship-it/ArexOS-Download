#include "kernel.h"

int main() {
    kernel_init();
    kernel_run();
    return 0;
}
