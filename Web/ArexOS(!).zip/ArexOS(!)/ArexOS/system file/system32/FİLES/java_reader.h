#ifndef JAVA_READER_H
#define JAVA_READER_H

void run_java(const char* path);

#endif
