#include "file_manager.h"

int main() {

    open_file("test.py");
    // open_file("Hello.java");
    // open_file("app.jar");

    return 0;
}
