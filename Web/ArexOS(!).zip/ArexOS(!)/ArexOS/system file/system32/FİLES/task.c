#include <stdio.h>
#include "task.h"

void task_init() {
    printf("[TASK] Gorev yoneticisi hazir\n");
}

void task_run() {
    printf("[TASK] Sistem calisiyor (idle task)\n");
}
