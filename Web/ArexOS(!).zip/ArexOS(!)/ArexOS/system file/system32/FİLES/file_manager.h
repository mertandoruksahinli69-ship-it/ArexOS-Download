#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

void open_file(const char* path);

#endif
