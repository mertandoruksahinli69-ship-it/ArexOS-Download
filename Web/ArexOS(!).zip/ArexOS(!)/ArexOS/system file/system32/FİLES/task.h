#ifndef TASK_H
#define TASK_H

void task_init();
void task_run();

#endif
