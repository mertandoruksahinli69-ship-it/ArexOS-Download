#ifndef PYTHON_READER_H
#define PYTHON_READER_H

void run_python(const char* path);

#endif
