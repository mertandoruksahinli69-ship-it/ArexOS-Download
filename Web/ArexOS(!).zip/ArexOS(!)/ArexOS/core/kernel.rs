#![no_std]
#![no_main]

extern "C" {
    fn cpu_init();
}

#[no_mangle]
pub extern "C" fn kernel_main() -> ! {
    unsafe {
        cpu_init();
    }

    loop {}
}
