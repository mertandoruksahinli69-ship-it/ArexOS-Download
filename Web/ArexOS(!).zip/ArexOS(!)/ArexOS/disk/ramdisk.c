#include "ramdisk.h"
#include "../memory/memory.h"

#define RAMDISK_SIZE 32768
static uint8_t* rd;

void ramdisk_init(void){
    rd = (uint8_t*)kmalloc(RAMDISK_SIZE);
    ramdisk_clear();
}
void ramdisk_write(size_t off, uint8_t v){
    if (off < RAMDISK_SIZE) rd[off] = v;
}
uint8_t ramdisk_read(size_t off){
    return (off < RAMDISK_SIZE) ? rd[off] : 0;
}
void ramdisk_clear(void){
    for(size_t i=0;i<RAMDISK_SIZE;i++) rd[i]=0;
}
