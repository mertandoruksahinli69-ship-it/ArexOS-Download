#ifndef RAMDISK_H
#define RAMDISK_H
#include "../core/types.h"
void ramdisk_init(void);
void ramdisk_write(size_t off, uint8_t v);
uint8_t ramdisk_read(size_t off);
void ramdisk_clear(void);
#endif
