// ============================================================
// AREX OS - Window Manager Core
// File: core/ui/window.c
// Architecture: x86 (Framebuffer Based)
// Mode: Kernel / Bare Metal Friendly
// ============================================================

#include "window.h"
#include "../../video/framebuffer.h"
#include <stdint.h>

/* ============================================================
   CONFIGURATION
   ============================================================ */

#define MAX_WINDOWS 16
#define TITLE_BAR_HEIGHT 20
#define WINDOW_BORDER 2

/* ============================================================
   WINDOW STRUCTURE
   ============================================================ */

typedef struct {
    uint32_t id;
    uint32_t x;
    uint32_t y;
    uint32_t width;
    uint32_t height;
    uint32_t bg_color;
    uint32_t border_color;
    uint8_t  visible;
    uint8_t  focused;
    char     title[32];
} arex_window_t;

/* ============================================================
   GLOBAL STATE
   ============================================================ */

static arex_window_t windows[MAX_WINDOWS];
static uint32_t window_count = 0;
static uint32_t focused_window = 0xFFFFFFFF;

/* ============================================================
   INTERNAL HELPERS
   ============================================================ */

static void draw_title_bar(arex_window_t* win)
{
    fb_draw_rect(
        win->x,
        win->y,
        win->width,
        TITLE_BAR_HEIGHT,
        0x303030
    );
}

static void draw_border(arex_window_t* win)
{
    fb_draw_rect_border(
        win->x,
        win->y,
        win->width,
        win->height,
        win->border_color
    );
}

static void draw_content(arex_window_t* win)
{
    fb_draw_rect(
        win->x + WINDOW_BORDER,
        win->y + TITLE_BAR_HEIGHT,
        win->width - WINDOW_BORDER * 2,
        win->height - TITLE_BAR_HEIGHT - WINDOW_BORDER,
        win->bg_color
    );
}

/* ============================================================
   WINDOW CORE API
   ============================================================ */

void wm_init()
{
    window_count = 0;
    focused_window = 0xFFFFFFFF;

    for (uint32_t i = 0; i < MAX_WINDOWS; i++) {
        windows[i].visible = 0;
        windows[i].focused = 0;
    }
}

int wm_create_window(
    uint32_t x,
    uint32_t y,
    uint32_t w,
    uint32_t h,
    uint32_t bg,
    uint32_t border,
    const char* title
) {
    if (window_count >= MAX_WINDOWS)
        return -1;

    arex_window_t* win = &windows[window_count];

    win->id = window_count;
    win->x = x;
    win->y = y;
    win->width = w;
    win->height = h;
    win->bg_color = bg;
    win->border_color = border;
    win->visible = 1;
    win->focused = 0;

    for (int i = 0; i < 31 && title[i]; i++)
        win->title[i] = title[i];
    win->title[31] = 0;

    window_count++;
    return win->id;
}

/* ============================================================
   FOCUS MANAGEMENT
   ============================================================ */

void wm_focus_window(uint32_t id)
{
    if (id >= window_count)
        return;

    for (uint32_t i = 0; i < window_count; i++)
        windows[i].focused = 0;

    windows[id].focused = 1;
    focused_window = id;
}

/* ============================================================
   DRAWING
   ============================================================ */

void wm_draw_window(uint32_t id)
{
    if (id >= window_count)
        return;

    arex_window_t* win = &windows[id];

    if (!win->visible)
        return;

    draw_border(win);
    draw_title_bar(win);
    draw_content(win);
}

void wm_draw_all()
{
    for (uint32_t i = 0; i < window_count; i++)
        wm_draw_window(i);
}

/* ============================================================
   WINDOW MOVEMENT
   ============================================================ */

void wm_move_window(uint32_t id, int dx, int dy)
{
    if (id >= window_count)
        return;

    windows[id].x += dx;
    windows[id].y += dy;
}

/* ============================================================
   HIT TESTING (MOUSE SUPPORT)
   ============================================================ */

int wm_window_at(int mx, int my)
{
    for (int i = window_count - 1; i >= 0; i--) {
        arex_window_t* win = &windows[i];

        if (!win->visible)
            continue;

        if (mx >= (int)win->x &&
            mx <= (int)(win->x + win->width) &&
            my >= (int)win->y &&
            my <= (int)(win->y + win->height)) {
            return win->id;
        }
    }
    return -1;
}

/* ============================================================
   CLOSE WINDOW
   ============================================================ */

void wm_close_window(uint32_t id)
{
    if (id >= window_count)
        return;

    windows[id].visible = 0;
    windows[id].focused = 0;

    if (focused_window == id)
        focused_window = 0xFFFFFFFF;
}

/* ============================================================
   DEBUG TEST WINDOW
   ============================================================ */

void wm_test_desktop()
{
    wm_create_window(50, 50, 300, 200, 0x404040, 0xFFFFFF, "AREX SYSTEM");
    wm_create_window(120, 120, 260, 180, 0x505050, 0x00FF00, "CONTROL");
    wm_focus_window(1);
    wm_draw_all();
}

/* ============================================================
   END OF FILE
   ============================================================ */
