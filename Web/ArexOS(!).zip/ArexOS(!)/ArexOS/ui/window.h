
// ============================================================
// AREX OS - Window Manager Header
// File: core/ui/window.h
// Architecture: x86
// Mode: Kernel / Bare Metal Compatible
// ============================================================

#ifndef AREX_WINDOW_H
#define AREX_WINDOW_H

#include <stdint.h>

/* ============================================================
   CONSTANTS
   ============================================================ */

#define AREX_MAX_WINDOWS        16
#define AREX_TITLE_LENGTH       32

#define AREX_TRUE               1
#define AREX_FALSE              0

/* ============================================================
   WINDOW STATES
   ============================================================ */

#define WINDOW_STATE_HIDDEN     0
#define WINDOW_STATE_VISIBLE    1

#define WINDOW_FOCUS_NONE       0
#define WINDOW_FOCUS_ACTIVE     1

/* ============================================================
   WINDOW COLORS (DEFAULT THEME)
   ============================================================ */

#define WINDOW_COLOR_BG         0x404040
#define WINDOW_COLOR_BORDER     0xFFFFFF
#define WINDOW_COLOR_TITLE      0x303030
#define WINDOW_COLOR_FOCUS      0x00AAFF

/* ============================================================
   WINDOW STRUCTURE
   ============================================================ */

typedef struct arex_window {
    uint32_t id;

    uint32_t x;
    uint32_t y;

    uint32_t width;
    uint32_t height;

    uint32_t background_color;
    uint32_t border_color;

    uint8_t  visible;
    uint8_t  focused;

    char     title[AREX_TITLE_LENGTH];

} arex_window_t;

/* ============================================================
   WINDOW MANAGER CORE API
   ============================================================ */

/**
 * Initialize window manager system
 */
void wm_init();

/**
 * Create a new window
 */
int wm_create_window(
    uint32_t x,
    uint32_t y,
    uint32_t width,
    uint32_t height,
    uint32_t bg_color,
    uint32_t border_color,
    const char* title
);

/**
 * Draw a single window
 */
void wm_draw_window(uint32_t id);

/**
 * Draw all visible windows
 */
void wm_draw_all();

/**
 * Set focus to a window
 */
void wm_focus_window(uint32_t id);

/**
 * Move window position
 */
void wm_move_window(uint32_t id, int dx, int dy);

/**
 * Close window
 */
void wm_close_window(uint32_t id);

/**
 * Find window under mouse
 */
int wm_window_at(int mouse_x, int mouse_y);

/* ============================================================
   DEBUG & TEST
   ============================================================ */

/**
 * Create demo desktop windows
 */
void wm_test_desktop();

/* ============================================================
   INTERNAL FLAGS (FUTURE USE)
   ============================================================ */

#define WM_FLAG_MOVABLE         (1 << 0)
#define WM_FLAG_RESIZABLE       (1 << 1)
#define WM_FLAG_CLOSABLE        (1 << 2)

/* ============================================================
   EVENT TYPES (FOR INPUT SYSTEM)
   ============================================================ */

typedef enum {
    WM_EVENT_NONE = 0,
    WM_EVENT_MOUSE_DOWN,
    WM_EVENT_MOUSE_UP,
    WM_EVENT_MOUSE_MOVE,
    WM_EVENT_KEY_PRESS,
    WM_EVENT_KEY_RELEASE
} wm_event_type_t;

/* ============================================================
   EVENT STRUCTURE
   ============================================================ */

typedef struct {
    wm_event_type_t type;
    int mouse_x;
    int mouse_y;
    int key;
} wm_event_t;

/* ============================================================
   EVENT HANDLING (PLACEHOLDER)
   ============================================================ */

void wm_handle_event(wm_event_t event);

/* ============================================================
   FUTURE EXPANSION NOTES
   ============================================================ */
/*
 - Z-order management
 - Window resizing
 - Window snapping
 - Transparency
 - Desktop icons
 - Taskbar
*/

/* ============================================================
   END OF FILE
   ============================================================ */

#endif // AREX_WINDOW_H
