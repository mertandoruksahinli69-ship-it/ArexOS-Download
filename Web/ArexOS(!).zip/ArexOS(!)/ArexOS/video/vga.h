#ifndef VGA_H
#define VGA_H
#include "../core/types.h"
void vga_clear(void);
void vga_putc(char c);
void vga_print(const char* s);
#endif
