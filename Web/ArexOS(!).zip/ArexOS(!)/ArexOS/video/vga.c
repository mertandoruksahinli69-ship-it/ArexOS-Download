#include "vga.h"

static volatile uint16_t* vga = (uint16_t*)0xB8000;
static uint16_t cur = 0;

void vga_clear(void){
    for(int i=0;i<80*25;i++) vga[i] = 0x0720;
    cur = 0;
}
void vga_putc(char c){
    if(c=='\n'){ cur += 80 - (cur%80); return; }
    vga[cur++] = (0x07<<8) | c;
}
void vga_print(const char* s){
    while(*s) vga_putc(*s++);
}
