// AREX OS - Framebuffer Driver
// File: video/framebuffer.c
// Architecture: x86 (32-bit)
// Mode: Bare Metal
// Author: AREX Core Team

#include "framebuffer.h"
#include <stdint.h>

/* =========================================================
   GLOBAL FRAMEBUFFER STATE
   ========================================================= */

static uint32_t* framebuffer = 0;
static uint32_t fb_width = 0;
static uint32_t fb_height = 0;
static uint32_t fb_pitch = 0;
static uint8_t fb_bpp = 0;

/* =========================================================
   LOW LEVEL INIT
   ========================================================= */

void fb_init(uint32_t addr,
             uint32_t width,
             uint32_t height,
             uint32_t pitch,
             uint8_t bpp)
{
    framebuffer = (uint32_t*)addr;
    fb_width = width;
    fb_height = height;
    fb_pitch = pitch;
    fb_bpp = bpp;
}

/* =========================================================
   BASIC PIXEL OPS
   ========================================================= */

void fb_put_pixel(uint32_t x, uint32_t y, uint32_t color)
{
    if (x >= fb_width) return;
    if (y >= fb_height) return;

    uint32_t index = (y * (fb_pitch / 4)) + x;
    framebuffer[index] = color;
}

uint32_t fb_get_pixel(uint32_t x, uint32_t y)
{
    if (x >= fb_width) return 0;
    if (y >= fb_height) return 0;

    uint32_t index = (y * (fb_pitch / 4)) + x;
    return framebuffer[index];
}

/* =========================================================
   SCREEN CLEAR
   ========================================================= */

void fb_clear(uint32_t color)
{
    for (uint32_t y = 0; y < fb_height; y++)
    {
        for (uint32_t x = 0; x < fb_width; x++)
        {
            fb_put_pixel(x, y, color);
        }
    }
}

/* =========================================================
   RECTANGLES
   ========================================================= */

void fb_draw_rect(uint32_t x,
                  uint32_t y,
                  uint32_t w,
                  uint32_t h,
                  uint32_t color)
{
    for (uint32_t iy = 0; iy < h; iy++)
    {
        for (uint32_t ix = 0; ix < w; ix++)
        {
            fb_put_pixel(x + ix, y + iy, color);
        }
    }
}

void fb_draw_rect_border(uint32_t x,
                         uint32_t y,
                         uint32_t w,
                         uint32_t h,
                         uint32_t color)
{
    for (uint32_t i = 0; i < w; i++)
    {
        fb_put_pixel(x + i, y, color);
        fb_put_pixel(x + i, y + h - 1, color);
    }

    for (uint32_t i = 0; i < h; i++)
    {
        fb_put_pixel(x, y + i, color);
        fb_put_pixel(x + w - 1, y + i, color);
    }
}

/* =========================================================
   GRADIENT BACKGROUND (DESKTOP FEEL)
   ========================================================= */

void fb_draw_vertical_gradient(uint32_t top,
                               uint32_t bottom)
{
    for (uint32_t y = 0; y < fb_height; y++)
    {
        uint8_t r1 = (top >> 16) & 0xFF;
        uint8_t g1 = (top >> 8) & 0xFF;
        uint8_t b1 = top & 0xFF;

        uint8_t r2 = (bottom >> 16) & 0xFF;
        uint8_t g2 = (bottom >> 8) & 0xFF;
        uint8_t b2 = bottom & 0xFF;

        uint8_t r = r1 + (r2 - r1) * y / fb_height;
        uint8_t g = g1 + (g2 - g1) * y / fb_height;
        uint8_t b = b1 + (b2 - b1) * y / fb_height;

        uint32_t color = (r << 16) | (g << 8) | b;

        for (uint32_t x = 0; x < fb_width; x++)
        {
            fb_put_pixel(x, y, color);
        }
    }
}

/* =========================================================
   DEBUG GRID (FOR UI DEV)
   ========================================================= */

void fb_draw_grid(uint32_t spacing, uint32_t color)
{
    for (uint32_t y = 0; y < fb_height; y += spacing)
    {
        for (uint32_t x = 0; x < fb_width; x++)
        {
            fb_put_pixel(x, y, color);
        }
    }

    for (uint32_t x = 0; x < fb_width; x += spacing)
    {
        for (uint32_t y = 0; y < fb_height; y++)
        {
            fb_put_pixel(x, y, color);
        }
    }
}

/* =========================================================
   SIMPLE DESKTOP BACKGROUND
   ========================================================= */

void fb_draw_desktop()
{
    fb_draw_vertical_gradient(0x1E3C72, 0x2A5298);

    fb_draw_rect(
        20,
        fb_height - 60,
        fb_width - 40,
        40,
        0x202020
    );
}

/* =========================================================
   END OF FILE
   ========================================================= */
