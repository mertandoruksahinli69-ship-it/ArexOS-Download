import sys
import os
from PyQt6.QtCore import *
from PyQt6.QtWidgets import *
from PyQt6.QtWebEngineWidgets import *
from PyQt6.QtGui import QAction, QIcon, QPalette, QColor

# GPU hatalarını önlemek için sandbox'ı devre dışı bırakıyoruz
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = "--no-sandbox"

class ArexBrowser(QMainWindow):
    def __init__(self):
        super().__init__()

        # Ana Tab Paneli
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.tabBarDoubleClicked.connect(self.tab_open_doubleclick)
        self.tabs.currentChanged.connect(self.current_tab_changed)
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_current_tab)
        
        # Stil Ayarları (Modern Koyu Tema)
        self.setStyleSheet("""
            QTabWidget::pane { border-top: 2px solid #333; }
            QTabBar::tab { background: #222; color: white; padding: 10px; min-width: 150px; }
            QTabBar::tab:selected { background: #444; }
            QLineEdit { padding: 8px; border-radius: 5px; background: #333; color: white; }
            QToolBar { background: #222; border-bottom: 1px solid #444; }
            QPushButton { color: white; font-weight: bold; border: none; padding: 5px; }
        """)

        self.setCentralWidget(self.tabs)

        # Navigasyon Çubuğu
        navbar = QToolBar("Navigasyon")
        navbar.setMovable(False)
        self.addToolBar(navbar)

        # Butonlar
        back_btn = QAction("◀", self)
        back_btn.triggered.connect(lambda: self.tabs.currentWidget().back())
        navbar.addAction(back_btn)

        next_btn = QAction("▶", self)
        next_btn.triggered.connect(lambda: self.tabs.currentWidget().forward())
        navbar.addAction(next_btn)

        reload_btn = QAction("↻", self)
        reload_btn.triggered.connect(lambda: self.tabs.currentWidget().reload())
        navbar.addAction(reload_btn)

        home_btn = QAction("🏠", self)
        home_btn.triggered.connect(self.navigate_home)
        navbar.addAction(home_btn)

        # Adres Çubuğu
        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.urlbar)

        # Yeni Sekme Butonu
        new_tab_btn = QAction("➕", self)
        new_tab_btn.triggered.connect(lambda: self.add_new_tab())
        navbar.addAction(new_tab_btn)

        # İlk sekmeyi aç
        self.add_new_tab(QUrl('https://www.google.com'), 'Ana Sayfa')

        self.setWindowTitle("Arex Browser")
        self.showMaximized()

    def add_new_tab(self, qurl=None, label="Yeni Sekme"):
        if qurl is None:
            qurl = QUrl('https://www.google.com')

        browser = QWebEngineView()
        browser.setUrl(qurl)
        
        i = self.tabs.addTab(browser, label)
        self.tabs.setCurrentIndex(i)

        # URL ve Başlık Güncellemeleri
        browser.urlChanged.connect(lambda qurl, browser=browser:
                                   self.update_urlbar(qurl, browser))
        
        browser.loadFinished.connect(lambda _, i=i, browser=browser:
                                     self.tabs.setTabText(i, browser.page().title()[:15] + "..."))

    def tab_open_doubleclick(self, i):
        if i == -1: self.add_new_tab()

    def current_tab_changed(self, i):
        if self.tabs.currentWidget():
            qurl = self.tabs.currentWidget().url()
            self.update_urlbar(qurl, self.tabs.currentWidget())

    def close_current_tab(self, i):
        if self.tabs.count() < 2: return
        self.tabs.removeTab(i)

    def update_urlbar(self, q, browser=None):
        if browser != self.tabs.currentWidget(): return
        self.urlbar.setText(q.toString())

    def navigate_home(self):
        self.tabs.currentWidget().setUrl(QUrl("https://www.google.com"))

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        if q.scheme() == "":
            # Eğer nokta yoksa arama motoruna yönlendir
            if "." not in self.urlbar.text():
                q = QUrl(f"https://www.google.com/search?q={self.urlbar.text()}")
            else:
                q.setScheme("https")
        self.tabs.currentWidget().setUrl(q)

app = QApplication(sys.argv)
app.setApplicationName("Arex Browser")
window = ArexBrowser()
app.exec()