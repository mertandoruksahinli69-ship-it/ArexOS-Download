/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __USBAUDIO_FCP_H
#define __USBAUDIO_FCP_H

int snd_fcp_init(struct usb_mixer_interface *mixer);

#endif /* __USBAUDIO_FCP_H */
