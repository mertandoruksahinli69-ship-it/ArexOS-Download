/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __USB_MIXER_SCARLETT2_H
#define __USB_MIXER_SCARLETT2_H

int snd_scarlett2_init(struct usb_mixer_interface *mixer);

#endif /* __USB_MIXER_SCARLETT2_H */
