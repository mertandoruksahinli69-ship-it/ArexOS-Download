/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Presonus Studio 1810c driver for ALSA
 * Copyright (C) 2019 Nick Kossifidis <mickflemm@gmail.com>
 */

int snd_sc1810_init_mixer(struct usb_mixer_interface *mixer);
