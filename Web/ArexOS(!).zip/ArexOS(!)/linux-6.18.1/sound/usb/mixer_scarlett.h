/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __USB_MIXER_SCARLETT_H
#define __USB_MIXER_SCARLETT_H

int snd_scarlett_controls_create(struct usb_mixer_interface *mixer);

#endif /* __USB_MIXER_SCARLETT_H */
