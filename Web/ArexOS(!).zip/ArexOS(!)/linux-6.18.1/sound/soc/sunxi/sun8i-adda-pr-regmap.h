/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright (C) 2018 Vasily Khoruzhick <anarsoul@gmail.com>
 */

struct regmap *sun8i_adda_pr_regmap_init(struct device *dev,
					 void __iomem *base);
