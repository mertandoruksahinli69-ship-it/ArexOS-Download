/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * ALSA SoC I2S (McBSP) Audio Layer for TI DAVINCI processor
 *
 * Author:      Vladimir Barinov, <vbarinov@embeddedalley.com>
 * Copyright:   (C) 2007 MontaVista Software, Inc., <source@mvista.com>
 */

#ifndef _DAVINCI_I2S_H
#define _DAVINCI_I2S_H

/* McBSP dividers */
enum davinci_mcbsp_div {
	DAVINCI_MCBSP_CLKGDV,              /* Sample rate generator divider */
};

#endif
